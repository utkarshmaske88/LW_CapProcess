#!/bin/bash
# installUefi.sh - perform the UEFI B&R hypervisor installation.

doUefiInstallation()
{
	local deviceName=$1

	checkLastParam "$deviceName" "no device name given."

	#generate random filename to mark the EFI-Partition where the BR Hyp GRUB is installed
	#For the filename a constant token is concatenated with a 10-char string with letters (capital and small) and numbers
	local efiPartMarkerFileName="efiPartMarker_$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 10 | head -n 1).efi"

	showInstProgress "0" "$deviceName"
	logWriteInstallStart "$deviceName"
	
	logWriteInitUninstallFile 

	# detect ESP partition
	getEspPartition espDevice espPartNr
	showInstProgress "10" "$deviceName"

	# save existing ESP data
	#saveEspData $espDevice $espPartNr
	showInstProgress "20" "$deviceName"

	#AR:
	# - create partition and format it with FAT
	createARPartitions arDevice arPartPrefix arPartNr
	showInstProgress "35" "$deviceName"

	# - copy Basis AR
	installInitialARemb $arDevice $arPartPrefix $arPartNr
	showInstProgress "50" "$deviceName"

	#hypervisor: create hypervisor configuration
	installHypervisorFiles $arDevice $arPartPrefix $arPartNr
	showInstProgress "65" "$deviceName"

	#grub: install grub in the ESP
	installUefiGrub2 gposName bootline $efiPartMarkerFileName $espDevice $espPartNr
	showInstProgress "80" "$deviceName"

	#create hypervisor configuration
	installUefiHypervisorCfg $espDevice $arDevice $arPartPrefix $arPartNr $efiPartMarkerFileName $gposName "$bootline"
	showInstProgress "90" "$deviceName"

	logWriteInstallFinished "$deviceName"
	showInstProgress "100" "$deviceName"

	hasDebugFile

	restartTarget
}
