#!/bin/bash
############################################################################
# installARemb.sh - A menu driven shell script to install ARemb on an APC. #
############################################################################

# print debug messages and optionally just simulate the action
DEBUG=1

SETUP_DIR="$1"
CHROOT_ENV="$2"				# "1" .. script started via chroot
ROOT_DIR="/root"
BASEAR_DIR=$ROOT_DIR"/BaseAR"
SHELL_SCRIPT_DIR=$ROOT_DIR"/scripts"
BOOT_INFO_DIR=$SHELL_SCRIPT_DIR

RTH_TRACE_FILE=log.txt
RTH_LOG_LEVEL=8
ARNBCFG_FILE=$SETUP_DIR"/arnbcfg.xml"

LINUX_VMLINUZ_NAME="bzImage"					#image_0
LINUX_INITRAMFS_NAME="initramfs-ppc80"			#image_1
LINUX_IMAGE_2="SSDT.aml"						#image_2 (optional)

GRUB_UEFI_TIMEOUT="0"
PPC80_TOUCH_SUPPORT="Y"

# Define variables
LSB=/usr/bin/lsb_release

# include scripts
source "${SHELL_SCRIPT_DIR}/touchHelper.sh"
source "${SHELL_SCRIPT_DIR}/uefiGuiMenuPPC8x.sh"
source "${SHELL_SCRIPT_DIR}/uefiInstallationPPC8x.sh"
source "${SHELL_SCRIPT_DIR}/info.sh"			# info.sh is generated via extinst AR build
source "${SHELL_SCRIPT_DIR}/bootlineHelper.sh"
source "${SHELL_SCRIPT_DIR}/guiHelper.sh"
source "${SHELL_SCRIPT_DIR}/helper.sh"
source "${SHELL_SCRIPT_DIR}/hypervisorHelper.sh"
source "${SHELL_SCRIPT_DIR}/partitionHelper.sh"
source "${SHELL_SCRIPT_DIR}/pipHelper.sh"
source "${SHELL_SCRIPT_DIR}/installInitialARemb.sh"
source "${SHELL_SCRIPT_DIR}/uefiEsp.sh"
source "${SHELL_SCRIPT_DIR}/uefiHypervisor.sh"
source "${SHELL_SCRIPT_DIR}/uefiInstallGrub2.sh"
source "${SHELL_SCRIPT_DIR}/uefiUninstallationFileCfg.sh"


_readPartitionLabel() 
{
	local __label=$1
	local device=$2
	local partNr=$3
	local fileSystem=$4

	checkLastParam $partNr "no partition number given."

	local label=
	local arembSetup="0"
	if [[ "$fileSystem" =~ "fat" ]]; then		#fat16 and fat32
		label=$(dosfslabel $device$partNr)

	elif [ "$fileSystem" = "ntfs" ]; then
		label=$(ntfslabel $device$partNr)

	elif [ "$fileSystem" = "ext2" ] || [ "$fileSystem" = "ext3" ] || [ "$fileSystem" = "ext4" ]; then
		label=$(e2label $device$partNr)
	fi

	eval "${__label}='${label}'"
}

_getFreeSpace()
{
	local __freeSpace=$1
	local devicePartNr=$2
	local free=
	local freeDir
	local i

	checkLastParam $devicePartNr "no device partNr given."

	mountPartition freeDir $devicePartNr

	local OIFS=$IFS
	IFS=$'\n'
	local dfOutput=$(df -m $freeDir)
	local arr=$dfOutput
	for i in $arr
	do
		if [ -n "$i" ]; then
			if [ "${i:0:10}" = "Filesystem" ]; then
				availableStart=$(echo "$i" | awk '{ print index ($0, "Available")-1;}')
			else
				free=$(echo ${i:$availableStart:9} | sed 's/ //g')
				break
			fi
		fi
	done
	IFS=$OIFS
	umount $freeDir
	eval "${__freeSpace}='${free}'"
}

function _getDiskNumberOfDevice(){
	local __num=$1
	local dev=$2

	checkLastParam $dev "no device given. _getDiskNumberOfDevice($__num, $dev)"

	local letter=${echo $dev | rev}
	letter=${letter:0:1}
	local num="0"
	if [ "$letter" = "a" ]; then
		num="0"
	elif [ "$letter" = "b" ]; then
		num="1"
	elif [ "$letter" = "c" ]; then
		num="2"
	elif [ "$letter" = "d" ]; then
		num="3"
	else
		num=$letter
	fi
	
	echo "num:"$num", letter:"$letter
	hasDebugFile
	
	eval "${__num}='${num}'"
}

_readSingleDrive()
{
	local drive=$1
	local driveSize=$2
	local driveLogSectorSize=$3
	local drivePhysSectorSize=$4
	local drivePartTable=$5
	local driveDesc=$6
	local driveNumber=$7
	local driveAhciPort=$8
	local i

	checkLastParam $driveAhciPort "no ahci port given."

	# read partition info
	local OIFS=$IFS
	IFS=$'\n'
	#local partedOutput=$(parted -s $drive unit MB print | sed 's/  */ /g')
	local partedOutput=$(parted -s $drive unit MB print free)
	local arr=$partedOutput
	local nextIsAPartition="0"
	for i in $arr
	do
		if [ -n "$i" ]; then
			firstHead=$(echo $i | cut -d ' ' -f 1)
			if [ "$firstHead" = "Number" ]; then
				nextIsAPartition="1"
				ignoreDisk=
				local numberStart=$(echo "$i" | awk '{ print index ($0, "Number");}')		#index of "Number"
				local startStart=$(echo "$i" | awk '{ print index ($0, "Start")-1;}')
				local endStart=$(echo "$i" | awk '{ print index ($0, "End")-1;}')
				local sizeStart=$(echo "$i" | awk '{ print index ($0, "Size")-1;}')
				if [ "$drivePartTable" = "msdos" ]; then
					local typeStart=$(echo "$i" | awk '{ print index ($0, "Type")-1;}')
				else
					local nameStart=$(echo "$i" | awk '{ print index ($0, "Name")-1;}')
				fi
				local fileSystemStart=$(echo "$i" | awk '{ print index ($0, "File system")-1;}')
				local flagsStart=$(echo "$i" | awk '{ print index ($0, "Flags")-1;}')
			else
				if [ "$nextIsAPartition" = "1" ]; then
					local partNr=$(echo ${i:$numberStart} | cut -d ' ' -f 1)
					if [ -n "$partNr" ]; then
						getPartitionPrefix partitionPrefix $drive
						partNr=$partitionPrefix$partNr
					fi
					local start=$(echo ${i:$startStart} | cut -d ' ' -f 1)
					local end=$(echo ${i:$endStart} | cut -d ' ' -f 1)
					local size=$(echo ${i:$sizeStart} | cut -d ' ' -f 1)
					if [ "$drivePartTable" = "msdos" ]; then
						type=$(echo ${i:$typeStart} | cut -d ' ' -f 1)
					else
						name=$(echo ${i:$nameStart} | cut -d ' ' -f 1)
					fi
					local fileSystem=$(echo ${i:$fileSystemStart} | cut -d ' ' -f 1)
					local flags=${i:$flagsStart}

					# hide partitions < 2MB
					local sizeInMB=${size//MB/}	# "MB" => ""
					if (( ( $(echo "${sizeInMB} < 2" | bc -l) ) )); then
						continue
					fi

					local partLabel=
					local freeSpaceInMb=

					if [ "$drivePartTable" = "msdos" ]; then
						if $( echo $fileSystem | grep -q 'linux-swap' ); then
							partLabel="swap"
						elif [ -n "$partNr" ]; then
							_readPartitionLabel partLabel $drive $partNr $fileSystem
							_getFreeSpace freeSpaceInMb $drive$partNr
						else
							partLabel=
							freeSpaceInMb=$sizeInMB
						fi
					else
						partLabel=$name
						if [ -z "$partNr" ]; then
							partLabel="unallocated"
						fi
						if [ -z "$fileSystem" ]; then
							fileSystem="unknown"
						fi
					fi

					if [ -z "$freeSpaceInMb" ]; then
						freeSpaceInMb="0"
					fi

					if [ -z "$partLabel" ]; then
						partLabel="untitled"
					fi

					# hide ARemb Install Stick and B&R dongle
					if [ "${partLabel}" == "AREMB-SETUP" ] || [ "${partLabel}" == "CODEMETER  " ]; then
						ignoreDisk=1
					fi

					if [ "$ignoreDisk" = "1" ]; then
						continue
					fi

					local grubPartDir
					local grubCfgFilePath=/boot/grub/grub.cfg
					mountPartition grubPartDir $drive$partNr
					local grubCfgFile=$grubPartDir$grubCfgFilePath
					local grubCfg
					if [ -f "$grubCfgFile" ]; then
  						grubCfg=$grubCfgFilePath
  						grubPartNr=$partNr
					else 
    					grubCfg="-"
						grubPartNr=
					fi
					umountDir $grubPartDir

					# fixed because of PP-C80
					local gposString="Linux"

					# save parameters in global arrays
					partitionDevice=("${partitionDevice[@]}" "$drive")
					partitionDiskNumber=("${partitionDiskNumber[@]}" "$driveNumber")
					partitionDeviceSize=("${partitionDeviceSize[@]}" "$driveSize")
					partitionDeviceLogSectorSize=("${partitionDeviceLogSectorSize[@]}" "$driveLogSectorSize")
					partitionDevicePhysSectorSize=("${partitionDevicePhysSectorSize[@]}" "$drivePhysSectorSize")
					partitionDevicePartTable=("${partitionDevicePartTable[@]}" "$drivePartTable")
					partitionDeviceDesc=("${partitionDeviceDesc[@]}" "$driveDesc")
					partitionDeviceAhciPort=("${partitionDeviceAhciPort[@]}" "$driveAhciPort")

					local partNrOnly=$(echo $partNr | sed 's/p//g')
					local partPrefix="-"     # darf kein Leerstring sein!
					if [ "$partNrOnly" != "$partNr" ]; then
						partPrefix="${partNr:0:1}"
					fi
					partitionPartNr=("${partitionPartNr[@]}" "$partNrOnly")
					partitionPartNrAll=("${partitionPartNrAll[@]}" "$partNr")
					partitionPartPrefix=("${partitionPartPrefix[@]}" "$partPrefix")
					
					partitionFs=("${partitionFs[@]}" "$fileSystem")
					if [ "$drivePartTable" = "msdos" ]; then
						partitionType=("${partitionType[@]}" "$type")
					fi
					local sizeInMb=${size//MB/}	# "MB" => ""
					partitionSize=("${partitionSize[@]}" "$sizeInMb")
					partitionFree=("${partitionFree[@]}" "$freeSpaceInMb")
					partitionStart=("${partitionStart[@]}" "$start")
					partitionEnd=("${partitionEnd[@]}" "$end")
					partitionLabel=("${partitionLabel[@]}" "$partLabel")
					partitionFlag=("${partitionFlag[@]}" "$flags")

					partitionDeviceGrubPartNr=("${partitionDeviceGrubPartNr[@]}" "$grubPartNr")
					partitionDeviceGrubCfg=("${partitionDeviceGrubCfg[@]}" "$grubCfg")
					partitionDeviceGposString=("${partitionDeviceGposString[@]}" "$gposString")

					if [ "1" = "0" ]; then
						echo "drive:$drive"
						echo "diskNumber:$driveNumber"
						echo "driveSize:$driveSize"
						echo "driveLogSectorSize:$driveLogSectorSize"
						echo "drivePhysSectorSize:$drivePhysSectorSize"
						echo "drivePartTable:$drivePartTable"
						echo "driveDesc:$driveDesc"
						echo "driveAhciPort:$driveAhciPort"
						echo "partNrOnly:$partNrOnly"
						echo "partNr:$partNr"
						echo "partPrefix:$partPrefix"
						echo "fileSystem:$fileSystem"
						echo "type:$type"
						echo "sizeInMb:$sizeInMb (MB)"
						echo "freeSpaceInMb:$freeSpaceInMb (MB)"
						echo "start:$start"
						echo "end:$end"
						echo "partLabel:$partLabel"
						echo "flags:$flags"
						echo "correspondingExtPartNr:$correspondingExtPartNr"
						echo "grubPartNr:$grubPartNr"
						echo "grubCfg:$grubCfg"
						echo "gposString:$gposString"
						pause
					fi
				fi
			fi
		fi
	done
	IFS=$OIFS
}

_readDrives()
{
	# delete arrays contents
	partitionDevice=()
	partitionDiskNumber=()
	partitionDeviceSize=()
	partitionDeviceLogSectorSize=()
	partitionDevicePhysSectorSize=()
	partitionDevicePartTable=()
	partitionDeviceDesc=()
	partitionDeviceAhciPort=()
	partitionDeviceGrubPartNr=()
	partitionDeviceGrubCfg=()
	partitionDeviceGposString=()
	partitionPartPrefix=()

	partitionPartNr=()
	partitionPartNrAll=()
	partitionFs=()
	partitionType=()
	partitionSize=()
	partitionFree=()
	partitionStart=()
	partitionEnd=()
	partitionLabel=()
	partitionFlag=()

	local drives=()
	local driveNumbers=()
	local driveSizes=()
	local driveLogSectorSizes=()
	local drivePhysSectorSizes=()
	local drivePartTables=()
	local driveDescs=()
	local driveAhciPort=()
	local i

	local usbDevice=$(mount | grep $SETUP_DIR | cut -d ' ' -f 1)
	usbDevice=${usbDevice:0:8}		#removing partition number

	# read all drives
	local OIFS=$IFS
	IFS=$'\n'
	local partedOutput=$(parted -l -m)
	local arr=$partedOutput
	for i in $arr
	do
		if [ -n "$i" ]; then
			if [ "$i" = "BYT;" ]; then
				nextIsADevice="1"
				let cnt=cnt+1
			else
				if [ "$nextIsADevice" = "1" ]; then
					nextIsADevice="0"
					local device=$(echo $i | cut -d ':' -f 1)
					local size=$(echo $i | cut -d ':' -f 2)
					local logSectorSize=$(echo $i | cut -d ':' -f 4)
					local physSectorSize=$(echo $i | cut -d ':' -f 5)
					local partTable=$(echo $i | cut -d ':' -f 6)
					local desc=$(echo $i | cut -d ':' -f 7)
					desc=${desc//;/}
					local ahciPort=$(lsscsi | grep "$device" | cut -d '[' -f 2 | cut -d ':' -f 1 )

					logWriteDeviceInfo $device

					# filter out usb install stick device
					if [ "$usbDevice" != "$device" ] || [ "$CHROOT_ENV" == "1" ] ; then
						getDiskNumberOfDevice deviceNumber $device

						drives=("${drives[@]}" "$device")
						driveNumbers=("${driveNumbers[@]}" "$deviceNumber")
						driveSizes=("${driveSizes[@]}" "$size")
						driveLogSectorSizes=("${driveLogSectorSizes[@]}" "$logSectorSize")
						drivePhysSectorSizes=("${drivePhysSectorSizes[@]}" "$physSectorSize")
						drivePartTables=("${drivePartTables[@]}" "$partTable")
						driveDescs=("${driveDescs[@]}" "$desc")
						driveAhciPort=("${driveAhciPort[@]}" "$ahciPort")
					fi
				fi
			fi
		fi
	done
	IFS=$OIFS

	# read partition info of each drive
	for (( i=0; i<${#drives[@]}; i++ ))
	do
		_readSingleDrive "${drives[$i]}" "${driveSizes[$i]}" "${driveLogSectorSizes[$i]}" \
		"${drivePhysSectorSizes[$i]}" "${drivePartTables[$i]}" "${driveDescs[$i]}" "${driveNumbers[$i]}" "${driveAhciPort[$i]}"
	done

	local j=
	### drive spezifische Werte nachziehen
	for (( j=0; j<${#drives[@]}; j++ ))
	do
		local currDrive=${drives[$j]}
		local deviceGrubPartNr=1		# default value if using windows
		local deviceGrubCfg="-" 		# default value if using windows

		for (( i=0; i<${#partitionDevice[@]}; i++ ))
		do
			local currDevice=${partitionDevice[$i]}
			if [ "$currDrive" = "$currDevice" ] ; then
				if [ "$deviceGrubCfg" = "-" ]; then
					if [ -n "${partitionDeviceGrubPartNr[$i]}" ]; then
						deviceGrubPartNr=${partitionDeviceGrubPartNr[$i]}
						deviceGrubCfg=${partitionDeviceGrubCfg[$i]}
						i="-1"			# for schleife ein zweites mal durchlaufen
					fi
				else		# bei den anderen partitionen nachziehen
					partitionDeviceGrubPartNr[$i]=$deviceGrubPartNr
					partitionDeviceGrubCfg[$i]=$deviceGrubCfg
				fi
			fi
		done
	done

	logWriteDebug "device and partition information:"
	# read partition info of each drive
	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		logWriteDebug "${partitionDevice[$i]}${partitionPartNrAll[$i]}, ${partitionDiskNumber[$i]}: ${partitionDeviceSize[$i]}, ${partitionDeviceLogSectorSize[$i]}, ${partitionDevicePhysSectorSize[$i]}, ${partitionDevicePartTable[$i]}, ${partitionDeviceDesc[$i]}, ${partitionDeviceGrubPartNr[$i]}, ${partitionDeviceGrubCfg[$i]}, ${partitionDeviceGposString[$i]}"
		logWriteDebug "    ${partitionFs[$i]}, ${partitionType[$i]}, ${partitionSize[$i]}, ${partitionFree[$i]}, ${partitionStart[$i]}, ${partitionEnd[$i]}, ${partitionLabel[$i]}, ${partitionFlag[$i]}"
	done
}

getAhciPortFromDevice()
{
    local i
    local __ahciPort=$1
    local dev=$2
    local port=
    
    logWriteDebugFunction "getAhciPort($__ahciPort, $dev)"

	checkLastParam $dev "no device given."
    
    for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
	    if [ "${partitionDevice[i]}" = "$dev" ]; then
	        port=${partitionDeviceAhciPort[i]}
        fi
	done
	
	eval "${__ahciPort}='${port}'"
}

_printPartitions()
{
	if [ "1" = "0" ]; then
		logWriteDebug "name: $1, cnt: $2, default: $3"
		shift
		shift
		shift
	
		while [ -n "$1" ]
		do
			logWriteDebug "$1 $2"
			shift
			shift
		done
		logWriteDebug ""
	fi
}

_getPartitionString()
{
	local __partString=$1
	local i=$2

	local partStr=

	partStr="${partitionDeviceDesc[$i]} (${partitionDeviceSize[$i]})"
	if [ -z "${partitionType[$i]}" ]; then
		partStr="${partStr}, unallocated"
	else
		partStr="${partStr}, ${partitionLabel[$i]}, ${partitionDeviceGposString[$i]}"
	fi

	#if (( (${partitionPartNr[$i]} >= 5) )); then			# logical drives
		#	partStr="  "${partitionLabel[$i]}
	#fi

	partStr="disk${partitionDiskNumber[$i]}: $partStr, ${partitionSize[$i]}MB (free:${partitionFree[$i]}MB) ${partitionFs[$i]}"
	eval "${__partString}='${partStr}'"
}

_getARembInstallationCandidate()
{
	local __driveString=$1
	local device=$2

	local j=
	local driveString=

	for (( j=0; j<${#partitionDevice[@]}; j++ ))
	do
		# loop until unpartitioned/unallocated space
		if [ "${partitionDevice[$j]}" = "$device" ]; then
			if [ -z "${partitionType[$j]}" ] && (( ( ${partitionFree[$j]} > $MIN_CFAST_SIZE) )); then
				driveString="disk${partitionDiskNumber[$j]}: ${partitionDeviceGposString[$j]} on ${partitionDeviceDesc[$j]} (${partitionDeviceSize[$j]}, ${partitionFree[$j]}MB free) "
				break
			fi
		fi
	done
	eval "${__driveString}='${driveString}'"
}

_createPartitionInfoStrings()
{
	ALL_PART_COUNTER=1
	ALL_PART_LIST=()  # variable where we will keep the list entries for menu dialog
	ALL_PART_IDX_LIST=()

	# all bootable partitions
	BOOT_PART_COUNTER=1
	BOOT_PART_LIST=()
	BOOT_PART_IDX_LIST=()
	defaultbootPartitionNr=0

	partitionComplete=()
	partitionCnt=0
	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		_getPartitionString candPartString $i

		# all partitions
		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$ALL_PART_COUNTER")
		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$candPartString")
		ALL_PART_IDX_LIST=("${ALL_PART_IDX_LIST[@]}" "$i")
		let ALL_PART_COUNTER=ALL_PART_COUNTER+1

		# all bootable partitions
		if [[ "${partitionFlag[$i]}" =~ "boot" ]]; then
			BOOT_PART_LIST=("${BOOT_PART_LIST[@]}" "$BOOT_PART_COUNTER")
			BOOT_PART_LIST=("${BOOT_PART_LIST[@]}" "$candPartString")
			BOOT_PART_IDX_LIST=("${BOOT_PART_IDX_LIST[@]}" "$i")
			if [ "$defaultbootPartitionNr" = "0" ]; then
				let defaultbootPartitionNr=$BOOT_PART_COUNTER
				bootPartitionNr=$i
			fi
			let BOOT_PART_COUNTER=BOOT_PART_COUNTER+1
		fi

		partitionComplete=("${partitionComplete[@]}" "$candPartString")
		let partitionCnt=$partitionCnt+1
	done

	_printPartitions "ALL_PART" $ALL_PART_COUNTER 0 ${ALL_PART_IDX_LIST[@]} ${ALL_PART_LIST[@]}
	_printPartitions "BOOT" $BOOT_PART_COUNTER $defaultbootPartitionNr ${BOOT_PART_IDX_LIST[@]} ${BOOT_PART_LIST[@]}
	_printPartitions "ALL" $partitionCnt 0 ${partitionComplete[@]}
}

# ignore CTRL+C, CTRL+Z and quit singles using the trap
trap '' SIGINT SIGQUIT

trap ctrl_z SIGTSTP
ctrl_z() { echo "** trapped Crtl-Z";   exit 0; }

trap ctrl_c INT
ctrl_c() { echo "** Trapped CTRL-C";   exit 0; }

# for testing, on real system wait 5 seconds only
myhostname=$(hostname)
if [ "$myhostname" = "buildroot" ]; then
	: #sleep 5 TODO enablen
fi

tempfile=./tempfile.txt

#############################################
# Receives the result given in the file in the first parameter from the dialog
_receiveResult()
{
   retv=$?
   if [ -f $1 ] ; then
       choice=$(cat $1)
   fi
   [ $retv -eq 1 -o $retv -eq 255 ] && exit
}

# main logic
#sleep 5			# waiting for 5 seconds

dmesg -n 1		# suppress all messages from the kernel (and its drivers) except panic messages from appearing on the console
loadkeys de
clear

# read drives and partitions
partitionsChanged=1

logWriteStart "PP-C8x"

getMinPartitionSizes

# main loop
uefiMainLoop

