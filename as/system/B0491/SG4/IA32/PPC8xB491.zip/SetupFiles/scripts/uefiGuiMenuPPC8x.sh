#!/bin/bash

AREMB_DIALOG_UEFI_BOOT_OPTION="Install stick must be booted with UEFI"
AREMB_DIALOG_LEGACY_GPOS_INSTALLATION="No EFI system partition (ESP) found"

AREMB_INSTALLATION_PARTITION_NAME="ARembInstallation"

_checkUsbUefiBoot()
{
    if [ ! -d "/sys/firmware/efi" ]; then
        logWriteDebug "USB stick was not booted with UEFI (no /sys/firmware/efi directory available)"

        showRebootErrorDialog "$AREMB_DIALOG_UEFI_BOOT_OPTION" \
"You cannot install B&R Hypervisor on a UEFI system when you have booted the USB install stick with legacy. You have to boot it with UEFI.

Please restart and choose the UEFI boot option."
    fi
}

_checkGposUefiInstallation()
{
    getEspPartition espDev espPart
    if [ -z "$espDev" ] || [ -z "$espPart" ] ; then
        logWriteDebug "The GPT disk does not contain an ESP."

        showRebootErrorDialog "$AREMB_DIALOG_LEGACY_GPOS_INSTALLATION" \
"There is no EFI system partition (ESP) available. You cannot install B&R Hypervisor on a GPT disk without an ESP.\n
- reinstall UEFI GPOS with an ESP (recommended) or\n
- create an msdos partition table on the disk and reinstall legacy GPOS.

Please restart and reinstall GPOS."
    fi
}

_checkDiskNumber()
{
   # freier platz fuer AR da, wahrscheinlich DISK_NUMBER falsch angegeben
	if [ "$defaultCandPartitionNr" = "0" ]; then
	    local errorText="No suitable free space for installation of ARemb available.\n\nPlease check the values of the following parameters:"
	    if [ -n "$DISK_NUMBER" ]; then
	        errorText=$errorText"\n    - DISK_NUMBER=$DISK_NUMBER"
	    fi
	    if [ "$MIN_FREE_SPACE_IN_MB" != "0" ]; then
	        errorText=$errorText"\n    - MIN_FREE_SPACE_IN_MB=$MIN_FREE_SPACE_IN_MB"
	    fi
		showRebootErrorDialog "$AREMB_DIALOG_INSTALL_TITLE" $errorText 
	fi
}

###############
#UEFI handling
uefiMainLoop()
{
	uefiInstall=1

	logWriteDebug "UEFI GPOS detected"
	
	_readDrives

	_createUefiARembInstallationCandidates
	_createUefiARembUninstallationCandidates
	_createUefiPartitionInfoStrings

	_checkGposUefiInstallation
	hasUninstallCfgFile newUefiUninstallation

	if [ "$newUefiUninstallation" = "1" ] ; then
	    hasDebugFile
	    doUefiUninstallationFileCfg "PP-C80"
	
	    _readDrives

	    _createUefiARembInstallationCandidates
	    _createUefiARembUninstallationCandidates
	    _createUefiPartitionInfoStrings
	fi

	_checkDiskNumber
	hasDebugFile
	doUefiInstallation "PP-C80"
}

# all free areas on which ARemb can be installed
_createUefiARembInstallationCandidates()
{
	local activated=
	local i=
	AREMB_CAND_PART_COUNTER=1
	AREMB_CAND_PART_LIST=()  # variable for possible bootable partitions
	AREMB_CAND_PART_IDX_LIST=()
	defaultCandPartitionNr=0

	logWriteDebugFunction "_createUefiARembInstallationCandidates()"

	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		_getUefiPartitionString candPartString activated $i "free"

		AREMB_CAND_PART_LIST=("${AREMB_CAND_PART_LIST[@]}" "$AREMB_CAND_PART_COUNTER")
		AREMB_CAND_PART_LIST=("${AREMB_CAND_PART_LIST[@]}" "$candPartString")

		if [ -n "$activated" ]; then
			AREMB_CAND_PART_IDX_LIST=("${AREMB_CAND_PART_IDX_LIST[@]}" "$i")
		else
			AREMB_CAND_PART_IDX_LIST=("${AREMB_CAND_PART_IDX_LIST[@]}" "")
		fi
		let AREMB_CAND_PART_COUNTER=AREMB_CAND_PART_COUNTER+1

	done
	_printPartitions "CAND_PART" $AREMB_CAND_PART_COUNTER $defaultCandPartitionNr ${AREMB_CAND_PART_IDX_LIST[@]} ${AREMB_CAND_PART_LIST[@]}
}

# the partition of an ARemb installation
_createUefiARembUninstallationCandidates()
{
	local activated=
	local i=
	UEFI_AREMB_INSTALLED_COUNTER=1
	UEFI_AREMB_INSTALLED_PART_LIST=()
	UEFI_AREMB_INSTALLED_PART_IDX_LIST=()
	currentInstalledARembPartitionNr=0

	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		_getUefiPartitionString candPartString activated $i "ARinst"

		UEFI_AREMB_INSTALLED_PART_LIST=("${UEFI_AREMB_INSTALLED_PART_LIST[@]}" "$UEFI_AREMB_INSTALLED_COUNTER")
		UEFI_AREMB_INSTALLED_PART_LIST=("${UEFI_AREMB_INSTALLED_PART_LIST[@]}" "$candPartString")
		
		if [ -n "$activated" ]; then
			UEFI_AREMB_INSTALLED_PART_IDX_LIST=("${UEFI_AREMB_INSTALLED_PART_IDX_LIST[@]}" "$i")
		else
			UEFI_AREMB_INSTALLED_PART_IDX_LIST=("${UEFI_AREMB_INSTALLED_PART_IDX_LIST[@]}" "")
		fi
		let UEFI_AREMB_INSTALLED_COUNTER=$UEFI_AREMB_INSTALLED_COUNTER+1
	done
	_printPartitions "AREMB INSTALLED" $UEFI_AREMB_INSTALLED_COUNTER $defaultUefiARembInstallationNr ${UEFI_AREMB_INSTALLED_PART_IDX_LIST[@]} ${UEFI_AREMB_INSTALLED_PART_LIST[@]}
}

_createUefiPartitionInfoStrings()
{
	ALL_PART_COUNTER=1
	ALL_PART_LIST=()  # variable where we will keep the list entries for menu dialog
	ALL_PART_IDX_LIST=()

	partitionComplete=()
	partitionCnt=0
	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		_getUefiPartitionString candPartString activated $i "all"

		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$ALL_PART_COUNTER")
		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$candPartString")
		ALL_PART_IDX_LIST=("${ALL_PART_IDX_LIST[@]}" "$i")
		let ALL_PART_COUNTER=ALL_PART_COUNTER+1

		partitionComplete=("${partitionComplete[@]}" "$candPartString")
		let partitionCnt=$partitionCnt+1
	done

	_printPartitions "ALL_PART" $ALL_PART_COUNTER 0 ${ALL_PART_IDX_LIST[@]} ${ALL_PART_LIST[@]}
	_printPartitions "ALL" $partitionCnt 0 ${partitionComplete[@]}
}

_getUefiPartitionString()
{
	local __partString=$1
	local __activated=$2
	local i=$3
	local mode=$4
	local color=
	local active=

	logWriteDebugFunction "_getUefiPartitionString($__partString,$__activated,$i,$mode)"

	checkLastParam $mode "no mode given."

	local diskStr="disk${partitionDiskNumber[$i]} (${partitionDeviceSize[$i]}): "
	local partStr="${partitionLabel[$i]}, ${partitionSize[$i]}MB (${partitionFs[$i]})"
	if [ "${partitionLabel[$i]}" = "unallocated" ]; then
		partStr="${partitionLabel[$i]}, ${partitionSize[$i]}MB"
	fi

	# drives with msdos partition layout are not supported for UEFI
	if [ ${partitionDevicePartTable[$i]} = "msdos" ];then
		color="\Zb\Z0"
	else
		if [ "$mode" = "free" ]; then
			if [ "${partitionLabel[$i]}" = "unallocated" ] && (( (${partitionSize[$i]} > $MIN_CFAST_SIZE) )) ; then
				active="1"
				color="\ZB\Z0"
				if [ "$defaultCandPartitionNr" = "0" ]; then
					if [ -z "$DISK_NUMBER" ] ; then
						let defaultCandPartitionNr=$i+1
					else      # Vorbelegung durch Anwender (fuer Silent Mode)
						if [ "$DISK_NUMBER" = "${partitionDiskNumber[$i]}" ] ; then
							let defaultCandPartitionNr=$i+1
						fi
					fi
				fi
			else
				color="\Zb\Z0"
			fi
		elif [ "$mode" = "ARinst" ]; then
			if [ "${partitionLabel[$i]}" = "$AREMB_INSTALLATION_PARTITION_NAME" ]; then
				active="1"
				color="\ZB\Z0"
				if [ "$currentInstalledARembPartitionNr" = "0" ]; then
					let currentInstalledARembPartitionNr=$i+1
				fi
			else
				color="\Zb\Z0"
			fi
		else		#do nothing
			active="1"
			color="\Zb\Z0"
		fi
	fi

	partStr=$color$diskStr$partStr
	eval "${__partString}='${partStr}'"
	eval "${__activated}='${active}'"
}