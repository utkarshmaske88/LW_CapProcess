#!/bin/bash

addRthCfgIrqPpc80Touch()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgIrqPpc80Touch($rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."

    echo "    \"IRQ_108\"                = uint32: 0"            >> $rthCfgFile 
    echo ""                                                      >> $rthCfgFile
    echo "[/IRQ/108]"                                            >> $rthCfgFile
    echo "    \"trigger_mode\"           = uint32: 1"            >> $rthCfgFile
    echo "    \"polarity\"               = uint32: 1"            >> $rthCfgFile
}

addRthCfgShmEntriesPpc80Touch()
{
	local rthCfgFile=$1

	logWriteDebugFunction "addRthCfgShmEntriesPpc80Touch($rthCfgFile)"

	checkLastParam $rthCfgFile "no RTH config file given."
	
	echo "[/SHM/1]"                                              >> $rthCfgFile
    echo "    \"name\"                   = \"i2c\""              >> $rthCfgFile
    echo "    \"base\"                   = uint64: 0x7AFB2000"   >> $rthCfgFile
    echo "    \"size\"                   = uint64: 0x1000"       >> $rthCfgFile
    echo ""                                                      >> $rthCfgFile
}