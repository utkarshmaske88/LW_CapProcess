#!/bin/bash

# Returns the device and partition number of the new created and formatted system partition for the AR installation.
createARPartitions()
{
	local __arDevice=$1
	local __arPartPrefix=$2
	local __arPartNr=$3
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembStartMB=${partitionStart[$ARembPartitionNr]}
	local arembEndMB=${partitionEnd[$ARembPartitionNr]}
	local arembSizeMB=${partitionSize[$ARembPartitionNr]}
	local arembFreeMB=${partitionFree[$ARembPartitionNr]}
	local arembDeviceDesc=${partitionDeviceDesc[$ARembPartitionNr]}

	checkLastParam $__arPartNr "no uuid arPartNr given."

	getPartitionPrefix arembDevicePartPrefix $arembDevice

	# search the selected free area on the CFast
	local OIFS=$IFS
	IFS=$'\n'
	local partedOut=$(parted -s $arembDevice unit MB print free)
	local arr=$partedOut
	local string
	local index=0
	local foundIndex=
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currStart=$(echo $string | cut -d ' ' -f 1)
			local currEnd=$(echo $string | cut -d ' ' -f 2)
			local currSize=$(echo $string | cut -d ' ' -f 3)

			if [ "$currStart" = "$arembStartMB" ] && [ "$currEnd" = "$arembEndMB" ] && [ "$currSize" = "${arembSizeMB}MB" ]; then
				foundIndex=$index
				break
			fi
		fi
		let index=index+1
	done

	# search the selected free area on the CFast with sectors
	local partedOut=$(parted -s $arembDevice unit s print free)
	local arr=$partedOut
	local string
	index=0
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currStart=$(echo $string | cut -d ' ' -f 1 | cut -d 's' -f 1)
			local currEnd=$(echo $string | cut -d ' ' -f 2 | cut -d 's' -f 1)
			local currSize=$(echo $string | cut -d ' ' -f 3 | cut -d 's' -f 1)

			if [ "$index" = "$foundIndex" ]; then
				break
			fi
		fi
		let index=index+1
	done
	IFS=$OIFS

	_alignStartSector startSector $currStart
	endSector=$currEnd

	_calculateStartAndEndSectors $startSector $endSector $currSize
	
	logWriteDebugFunctionCall "parted -s $arembDevice mkpart "$AREMB_INSTALLATION_PARTITION_NAME" fat32 ${START_SECTORS[0]} ${END_SECTORS[0]}"

	_getPartNumber arSystemPartNumber $arembDevice ${START_SECTORS[0]} ${END_SECTORS[0]}
	partNumber=$arSystemPartNumber
	
	local partNumberNvmeCompatible=$arembDevicePartPrefix$partNumber
	logWriteDebugFunctionCall "mkfs -t fat $arembDevice$partNumberNvmeCompatible"
	
	getAhciPortFromDevice ahciPort $arembDevice
	logWriteAddUninstallCmd "delPart $ahciPort $partNumber"
	logWriteDebugFunctionCall "dosfslabel $arembDevice$partNumberNvmeCompatible SYSTEM"
	
	for (( i=1; i<${#START_SECTORS[@]}; i++ ))
	do
		logWriteDebugFunctionCall "parted -s $arembDevice mkpart "$AREMB_INSTALLATION_PARTITION_NAME"$i fat32 ${START_SECTORS[$i]} ${END_SECTORS[$i]}"
		let partNumber=$partNumber+1
		partNumberNvmeCompatible=$arembDevicePartPrefix$partNumber
		logWriteDebugFunctionCall "mkfs -t fat $arembDevice$partNumberNvmeCompatible"
		logWriteAddUninstallCmd "delPart $ahciPort $partNumber"
	done

	let partNumber=$arSystemPartNumber+1
	if (( 2 == ${#START_SECTORS[@]} )) ; then
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber USER"
	elif (( 3 == ${#START_SECTORS[@]} )) ; then
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber RPSHD"
		let partNumber=$partNumber+1
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber RPSHDS"
	elif (( 4 == ${#START_SECTORS[@]} )) ; then
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber RPSHD"
		let partNumber=$partNumber+1
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber RPSHDS"
		let partNumber=$partNumber+1
		logWriteDebugFunctionCall "dosfslabel $arembDevice$arembDevicePartPrefix$partNumber USER"
	fi

	logWriteInfo "partition for B&R Hypervisor and ARemb created on disk $arembDeviceDesc"

	eval "${__arDevice}='${arembDevice}'"
	eval "${__arPartPrefix}='${arembDevicePartPrefix}'"
	eval "${__arPartNr}='${arSystemPartNumber}'"
}

_alignSectorsDownTo1MiB()		# round down to 2048
{
	local __roundedSectors=$1
	local sectors=$2
	local roundedSectors=
	let sectorsPerMiB=1024*1024/512          # 2048 Sectors/MB (512 bytes/sector)
	
	logWriteDebugFunction "_alignSectorsDownTo1MiB($__roundedSectors,$sectors)"

	checkLastParam $sectors "no sectors given."
	
	let roundedSectors=$sectors/$sectorsPerMiB*$sectorsPerMiB
	
	eval "${__roundedSectors}='${roundedSectors}'"
}

_calculateStartAndEndSectors()
{
	local startSecFreeSpace=$1
	local endSecFreeSpace=$2
	local sizeFreeSpace=$3
	
	logWriteDebugFunction "_calculateStartAndEndSectors($startSecFreeSpace,$endSecFreeSpace,$sizeFreeSpace)"
	
	checkLastParam $sizeFreeSpace "no sizeFreeSpace given."
	
	let sectorsPerMiB=1024*1024/512          # 2048 Sectors/MB (512 bytes/sector)
	local remainingSectors=0
	local remainingSectorsPerPart=0
	
	let remainingSectors=$sizeFreeSpace-$MIN_CFAST_SIZE*$sectorsPerMiB
	let remainingSectorsPerPart=$remainingSectors/${#MIN_PART_SIZES[@]}
	_alignSectorsDownTo1MiB alignedRemainingSectorsPerPart $remainingSectorsPerPart
	

	START_SECTORS=()
	END_SECTORS=()
	local startSec=
	local endSec=$startSecFreeSpace
	for (( i=0; i<${#MIN_PART_SIZES[@]}; i++ ))
	do
		let startSec=$endSec
		let endSec=$startSec+${MIN_PART_SIZES[$i]}*$sectorsPerMiB+$alignedRemainingSectorsPerPart-1
		if (( i == ${#MIN_PART_SIZES[@]}-1 )); then		# last partition reaches until end of this free space
			endSec=$endSecFreeSpace
		fi
		
		START_SECTORS=("${START_SECTORS[@]}" "${startSec}s")
		END_SECTORS=("${END_SECTORS[@]}" "${endSec}s")
		let endSec=$endSec+1
	done
}

_alignStartSector () {
	local __alignedStartSector=$1
	local startSec=$2
	local alignTo=
	local sectorSize=
	local alignedStartSector=

	checkLastParam $startSec "startSector not given"

	let alignTo=1024*1024		# 1MiB
	let sectorSize=512          # 512 bytes/sector
	let numberOfSectors=$alignTo/$sectorSize

	let startSec=$startSec+$numberOfSectors-1
	let alignedStartSector=$startSec/$numberOfSectors*$numberOfSectors
	
	eval "${__alignedStartSector}='${alignedStartSector}'"
}

_getPartNumber()
{
	local __partNr=$1
	local device=$2
	local startSector=$3
	local endSector=$4

	checkLastParam $endSector "no end sector given."

	# search the new created partition on the CFast with sectors
	local OIFS=$IFS
	IFS=$'\n'
	local partedOut=$(parted -s $arembDevice unit s print free)
	local arr=$partedOut
	local string
	index=0
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currPartNr=$(echo $string | cut -d ' ' -f 1)
			local currStart=$(echo $string | cut -d ' ' -f 2)
			local currEnd=$(echo $string | cut -d ' ' -f 3)

			if [ "$currStart" = "$startSector" ] && [ "$currEnd" = "$endSector" ] ; then
				break
			fi
		fi
		let index=index+1
	done
	IFS=$OIFS

	eval "${__partNr}='${currPartNr}'"
}

# /dev/sda     => "1"
# /dev/sdb     => "2"
# /dev/nvme0n1 => "1"
# /dev/nvme0n2 => "2"
function getDiskNumberOfDevice(){
	local __num=$1
	local dev=$2

	checkLastParam $dev "no device given. getDiskNumberOfDevice($__num, $dev)"

	local letter=$(echo $dev | rev)
	letter=${letter:0:1}
	local num="0"
	if [ "$letter" = "a" ]; then
		num="0"
	elif [ "$letter" = "b" ]; then
		num="1"
	elif [ "$letter" = "c" ]; then
		num="2"
	elif [ "$letter" = "d" ]; then
		num="3"
	else
		num=$letter
	fi

	eval "${__num}='${num}'"
}