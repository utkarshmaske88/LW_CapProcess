#!/bin/bash

getBootLine() 
{
	local __bootline=$1
	local grubDev=$2
	local grubPartNr=$3
	local gpos=$4
	local grubCfg=$5

	logWriteDebugFunction "getBootLine($__bootline, $grubDev, $grubPartNr, $gpos, $grubCfg)"

	checkLastParam $grubCfg "no grub cfg given."

	bootline="-"
	if [ "$gpos" != "$WINDOWS_TAG" ]; then
		local arembSysPart=
		local grubPart=
		mountPartition grubPart $grubDev$grubPartNr

		getBootlineString bootline $grubPart$grubCfg

		umountDir $grubPart
	fi

	eval "$__bootline='$bootline'"
}

getBootlineString()
{
	local __bl=$1
	local grubCfgPath=$2
	local bl=

	logWriteDebugFunction "getBootlineString($__bl, $grubCfgPath)"

	checkLastParam $grubCfgPath "no grub cfg given."

	bl=$(grep "linux" $grubCfgPath | grep -i "$LINUX_VMLINUZ_NAME" | sed 's/\s/ /g' | sed 's/  / /g' | cut -d ' ' -f 4- | head -n 1)
	logWriteDebug "bootline: $bl"
	eval "$__bl='$bl'"
}
